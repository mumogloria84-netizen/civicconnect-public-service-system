import os
import sqlite3
import secrets
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(BASE_DIR, "service_requests.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(32))
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

CATEGORIES = ["Roads & Streetlights", "Water & Drainage", "Garbage Collection",
              "Public Safety", "Parks & Public Spaces", "Other"]
STATUSES = ["Pending", "In Progress", "Resolved"]


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'citizen',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reference TEXT NOT NULL UNIQUE,
            user_id INTEGER NOT NULL,
            category TEXT NOT NULL,
            location TEXT NOT NULL,
            description TEXT NOT NULL,
            image_filename TEXT,
            status TEXT NOT NULL DEFAULT 'Pending',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS status_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            request_id INTEGER NOT NULL,
            status TEXT NOT NULL,
            note TEXT,
            changed_at TEXT NOT NULL,
            FOREIGN KEY(request_id) REFERENCES requests(id) ON DELETE CASCADE
        );
        """)


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def current_user():
    if "user_id" not in session:
        return None
    with get_db() as db:
        return db.execute("SELECT id, name, email, role FROM users WHERE id=?",
                          (session["user_id"],)).fetchone()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        if user["role"] != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.context_processor
def inject_globals():
    return {"current_user": current_user(), "categories": CATEGORIES, "statuses": STATUSES}


@app.route("/")
def index():
    with get_db() as db:
        stats = {
            "total": db.execute("SELECT COUNT(*) FROM requests").fetchone()[0],
            "open": db.execute("SELECT COUNT(*) FROM requests WHERE status != 'Resolved'").fetchone()[0],
            "resolved": db.execute("SELECT COUNT(*) FROM requests WHERE status = 'Resolved'").fetchone()[0],
        }
        recent = db.execute("""
            SELECT r.*, u.name AS citizen_name FROM requests r
            JOIN users u ON u.id=r.user_id
            ORDER BY r.created_at DESC LIMIT 5
        """).fetchall()
    return render_template("index.html", stats=stats, recent=recent)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 8:
            flash("Enter your name and email, and use a password of at least 8 characters.", "danger")
            return render_template("register.html")
        try:
            with get_db() as db:
                db.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                           (name, email, generate_password_hash(password), "citizen", now()))
            flash("Account created. You can now log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("An account with that email already exists.", "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with get_db() as db:
            user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash(f"Welcome back, {user['name'].split()[0]}.", "success")
            return redirect(url_for("admin_dashboard" if user["role"] == "admin" else "my_requests"))
        flash("Email or password was incorrect.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


@app.route("/requests/new", methods=["GET", "POST"])
@login_required
def new_request():
    if request.method == "POST":
        category = request.form.get("category", "")
        location = request.form.get("location", "").strip()
        description = request.form.get("description", "").strip()
        image = request.files.get("image")
        if category not in CATEGORIES or not location or not description:
            flash("Please complete the category, location, and description fields.", "danger")
            return render_template("new_request.html")
        filename = None
        if image and image.filename:
            if not allowed_file(image.filename):
                flash("Image must be PNG, JPG, JPEG, GIF, or WEBP.", "danger")
                return render_template("new_request.html")
            filename = secure_filename(image.filename)
            stem, ext = os.path.splitext(filename)
            filename = f"{secrets.token_hex(8)}_{stem[:40]}{ext.lower()}"
            image.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))
        ref = "PSR-" + secrets.token_hex(4).upper()
        timestamp = now()
        user = current_user()
        with get_db() as db:
            cur = db.execute("""
                INSERT INTO requests(reference,user_id,category,location,description,image_filename,status,created_at,updated_at)
                VALUES(?,?,?,?,?,?, 'Pending', ?, ?)
            """, (ref, user["id"], category, location, description, filename, timestamp, timestamp))
            request_id = cur.lastrowid
            db.execute("INSERT INTO status_history(request_id,status,note,changed_at) VALUES(?,?,?,?)",
                       (request_id, "Pending", "Request submitted", timestamp))
        flash(f"Request submitted successfully. Your reference is {ref}.", "success")
        return redirect(url_for("request_detail", request_id=request_id))
    return render_template("new_request.html")


@app.route("/my-requests")
@login_required
def my_requests():
    user = current_user()
    status = request.args.get("status", "")
    query = """SELECT * FROM requests WHERE user_id=?"""
    params = [user["id"]]
    if status in STATUSES:
        query += " AND status=?"
        params.append(status)
    query += " ORDER BY created_at DESC"
    with get_db() as db:
        rows = db.execute(query, params).fetchall()
    return render_template("my_requests.html", requests=rows, selected_status=status)


@app.route("/requests/<int:request_id>")
@login_required
def request_detail(request_id):
    user = current_user()
    with get_db() as db:
        row = db.execute("""SELECT r.*, u.name AS citizen_name, u.email AS citizen_email
                            FROM requests r JOIN users u ON u.id=r.user_id WHERE r.id=?""",
                         (request_id,)).fetchone()
        history = db.execute("SELECT * FROM status_history WHERE request_id=? ORDER BY changed_at DESC",
                             (request_id,)).fetchall()
    if not row:
        abort(404)
    if user["role"] != "admin" and row["user_id"] != user["id"]:
        abort(403)
    return render_template("request_detail.html", item=row, history=history)


@app.route("/admin")
@admin_required
def admin_dashboard():
    status = request.args.get("status", "")
    category = request.args.get("category", "")
    search = request.args.get("q", "").strip()
    sql = """SELECT r.*, u.name AS citizen_name FROM requests r JOIN users u ON u.id=r.user_id WHERE 1=1"""
    params = []
    if status in STATUSES:
        sql += " AND r.status=?"
        params.append(status)
    if category in CATEGORIES:
        sql += " AND r.category=?"
        params.append(category)
    if search:
        sql += " AND (r.reference LIKE ? OR r.location LIKE ? OR u.name LIKE ? OR r.description LIKE ?)"
        params.extend([f"%{search}%"] * 4)
    sql += " ORDER BY CASE r.status WHEN 'Pending' THEN 1 WHEN 'In Progress' THEN 2 ELSE 3 END, r.created_at DESC"
    with get_db() as db:
        rows = db.execute(sql, params).fetchall()
        stats = {
            "total": db.execute("SELECT COUNT(*) FROM requests").fetchone()[0],
            "pending": db.execute("SELECT COUNT(*) FROM requests WHERE status='Pending'").fetchone()[0],
            "progress": db.execute("SELECT COUNT(*) FROM requests WHERE status='In Progress'").fetchone()[0],
            "resolved": db.execute("SELECT COUNT(*) FROM requests WHERE status='Resolved'").fetchone()[0],
        }
    return render_template("admin.html", requests=rows, stats=stats,
                           selected_status=status, selected_category=category, search=search)


@app.route("/admin/requests/<int:request_id>/status", methods=["POST"])
@admin_required
def update_status(request_id):
    status = request.form.get("status", "")
    note = request.form.get("note", "").strip()
    if status not in STATUSES:
        flash("Invalid status selected.", "danger")
        return redirect(url_for("admin_dashboard"))
    timestamp = now()
    with get_db() as db:
        item = db.execute("SELECT id FROM requests WHERE id=?", (request_id,)).fetchone()
        if not item:
            abort(404)
        db.execute("UPDATE requests SET status=?, updated_at=? WHERE id=?", (status, timestamp, request_id))
        db.execute("INSERT INTO status_history(request_id,status,note,changed_at) VALUES(?,?,?,?)",
                   (request_id, status, note or f"Status changed to {status}", timestamp))
    flash("Request status updated.", "success")
    return redirect(request.referrer or url_for("admin_dashboard"))


@app.errorhandler(403)
def forbidden(_error):
    return render_template("error.html", code=403, message="You do not have permission to view this page."), 403


@app.errorhandler(404)
def not_found(_error):
    return render_template("error.html", code=404, message="The page or request could not be found."), 404


with app.app_context():
    init_db()


if __name__ == "__main__":
    app.run(debug=True)
