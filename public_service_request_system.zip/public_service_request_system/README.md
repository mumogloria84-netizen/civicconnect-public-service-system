# CivicConnect — Public Service Request System

A Flask + SQLite web application for citizens to report community issues and track progress, while administrators manage reports and view basic service analytics.

## Features

- Citizen registration and login with hashed passwords
- Role-based citizen and administrator access
- Submit reports with category, location, description, and optional image
- Automatically generated reference numbers
- Citizen request list and individual request tracking
- Admin dashboard with total, pending, in-progress, and resolved counts
- Search and filter requests
- Status history/timeline
- Responsive layout for desktop and mobile
- Input validation and image extension/size limits

## Requirements

- Python 3.10 or later
- pip

## Run locally (Windows)

1. Extract the ZIP.
2. Open Command Prompt or PowerShell in the extracted `public_service_request_system` folder.
3. Create a virtual environment:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use Command Prompt and run:
   `.\.venv\Scripts\activate.bat`

4. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Set a secret key for local development (PowerShell):

   ```powershell
   $env:SECRET_KEY = "replace-this-with-a-long-random-secret"
   ```

6. Start the app:

   ```powershell
   python app.py
   ```

7. Open http://127.0.0.1:5000 in your browser.

The SQLite database is created automatically on first run.

## Create an administrator account

For safety, public registration only creates citizen accounts. To promote your own account:

1. Register a normal account through the website.
2. Stop the app with `Ctrl+C`.
3. Run the following command from the project folder, replacing `your-email@example.com` with your registered email:

   ```powershell
   python -c "import sqlite3; c=sqlite3.connect('service_requests.db'); c.execute(\"UPDATE users SET role='admin' WHERE email=?\", ('your-email@example.com',)); c.commit(); c.close(); print('Admin role updated')"
   ```

4. Restart the app and log in again. The Admin dashboard link will appear.

## Main routes

| Route | Purpose |
|---|---|
| `/` | Public home and aggregate statistics |
| `/register` | Citizen registration |
| `/login` | Login |
| `/requests/new` | Submit a request |
| `/my-requests` | View your requests |
| `/requests/<id>` | Request details and status timeline |
| `/admin` | Admin dashboard and filters |

## Project structure

```text
public_service_request_system/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── static/
│   ├── style.css
│   └── uploads/
└── templates/
    ├── base.html
    ├── index.html
    ├── register.html
    ├── login.html
    ├── new_request.html
    ├── my_requests.html
    ├── request_detail.html
    ├── admin.html
    └── error.html
```

## Database tables

- `users`: accounts, password hashes, roles
- `requests`: request details and current status
- `status_history`: chronological status updates and notes

## Notes before production deployment

This is a learning/demo project. Before public production use, add CSRF protection, rate limiting, stronger upload content validation, a production WSGI server, HTTPS, a persistent upload store, backups, and a managed database. Set `SECRET_KEY` using the deployment platform's environment variables. Do not use Flask's debug server in production.

## Suggested deployment

A Python-compatible hosting platform can run this Flask app. Configure the start command as:

```bash
gunicorn app:app
```

Add `gunicorn` to `requirements.txt` before using that command. Make sure the host provides persistent storage for SQLite and uploads; otherwise use a managed database and object storage. Follow the selected host's current setup guide.
